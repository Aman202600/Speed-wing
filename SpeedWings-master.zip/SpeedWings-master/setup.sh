#!/bin/bas

# Install dependencies
npm install
npm install animejs
npm install swiper
npm install dotenv

npm start