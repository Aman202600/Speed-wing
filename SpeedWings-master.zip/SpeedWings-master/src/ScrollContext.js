import { createContext } from 'react';

export const ScrollContext = createContext(null);